# FS22_AutoRepair
AutoRepair keeps your vehicle healty.

    + Repairs your vehicle automaticly when it has more than 5% damage.

## How to use:
* You only need to place this mod in your fs22 mods folder, no settings needed to set.

This mod is made by me from scratch.

If you have any issues with the mod or anything related, please contact me on:
https://github.com/Bobster82/FS22_AutoRepair

If you like my work and would like to support me:
Copyright (C) Bobster82

<a href="https://www.buymeacoffee.com/Bobster82" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-blue.png" alt="Buy Me A Coffee" height="41" width="174"></a>